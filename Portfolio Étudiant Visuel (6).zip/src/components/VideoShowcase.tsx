import { Play } from "lucide-react";
import { useState } from "react";

export function VideoShowcase() {
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <section className="py-24 bg-neutral-950">
      <div className="container mx-auto px-4 sm:px-6">
        <div className="text-center mb-12">
          <p className="text-red-500 mb-4 tracking-wider text-sm sm:text-base">SHOWREEL</p>
          <h2 className="text-white mb-4">Présentation Audi Q8 e-tron</h2>
          <p className="text-neutral-400 max-w-2xl mx-auto text-sm sm:text-base">
            Découvrez ma vidéo de présentation de l'Audi Q8 e-tron
          </p>
        </div>

        <div className="max-w-5xl mx-auto">
          <div className="relative aspect-video bg-neutral-900 rounded-2xl overflow-hidden border-2 border-red-500/20 shadow-2xl shadow-red-500/10">
            {!isPlaying ? (
              <div 
                className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-neutral-900 to-neutral-950 cursor-pointer"
                style={{
                  backgroundImage: 'url(https://img.youtube.com/vi/3UhJxy16EUY/maxresdefault.jpg)',
                  backgroundSize: 'cover',
                  backgroundPosition: 'center'
                }}
                onClick={() => setIsPlaying(true)}
              >
                <div className="absolute inset-0 bg-black/40"></div>
                <div className="text-center relative z-10">
                  <button
                    className="group mb-6"
                  >
                    <div className="w-24 h-24 bg-red-500 hover:bg-red-600 rounded-full flex items-center justify-center transition-all transform group-hover:scale-110 shadow-lg shadow-red-500/50">
                      <Play className="text-white ml-1" size={40} fill="white" />
                    </div>
                  </button>
                  <p className="text-white mb-2">Cliquez pour regarder</p>
                </div>
              </div>
            ) : (
              <iframe
                className="w-full h-full"
                src="https://www.youtube.com/embed/3UhJxy16EUY?autoplay=1"
                title="Présentation Audi Q8 e-tron"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            )}
          </div>

          {/* Informations supplémentaires */}
          <div className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
            <div className="bg-neutral-900 p-4 sm:p-6 rounded-lg border border-neutral-800 text-center">
              <p className="text-red-500 mb-2 text-sm sm:text-base">Projet</p>
              <p className="text-white text-sm sm:text-base">Audi Q8 e-tron</p>
            </div>
            <div className="bg-neutral-900 p-4 sm:p-6 rounded-lg border border-neutral-800 text-center">
              <p className="text-red-500 mb-2 text-sm sm:text-base">Type</p>
              <p className="text-white text-sm sm:text-base">Vidéo Promotionnelle</p>
            </div>
            <div className="bg-neutral-900 p-4 sm:p-6 rounded-lg border border-neutral-800 text-center">
              <p className="text-red-500 mb-2 text-sm sm:text-base">Compétences</p>
              <p className="text-white text-sm sm:text-base">Montage • Motion Design</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}