import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Camera, Video } from "lucide-react";

interface ProjectCardProps {
  project: {
    id: number;
    title: string;
    category: string;
    image: string;
    description: string;
    tags: string[];
    type?: string;
  };
}

export function ProjectCard({ project }: ProjectCardProps) {
  return (
    <div className="group relative bg-neutral-800 rounded-lg overflow-hidden hover:transform hover:scale-105 transition-all duration-300">
      <div className="aspect-[4/3] overflow-hidden relative">
        <ImageWithFallback
          src={project.image}
          alt={project.title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        {/* Badge avec icône photo ou vidéo */}
        <div className="absolute top-4 right-4 bg-red-500 p-2 rounded-lg shadow-lg">
          {project.type === "video" ? (
            <Video className="text-white" size={20} />
          ) : (
            <Camera className="text-white" size={20} />
          )}
        </div>
      </div>
      
      <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
        <p className="text-red-500 mb-2">{project.category}</p>
        <h3 className="text-white mb-2">{project.title}</h3>
        <p className="text-neutral-300 mb-4">{project.description}</p>
        <div className="flex flex-wrap gap-2">
          {project.tags.map((tag, index) => (
            <span
              key={index}
              className="text-xs bg-neutral-800/80 text-neutral-300 px-3 py-1 rounded-full"
            >
              {tag}
            </span>
          ))}
        </div>
      </div>

      <div className="p-6">
        <p className="text-red-500 mb-2">{project.category}</p>
        <h3 className="text-white">{project.title}</h3>
      </div>
    </div>
  );
}