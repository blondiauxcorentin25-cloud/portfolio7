import { ChevronDown } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Hero() {
  const scrollToProjects = () => {
    const element = document.getElementById("projets");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="accueil" className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      {/* Background Image */}
      <div className="absolute inset-0">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1638909469623-4fdd7758414b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyYWNpbmclMjBjYXIlMjBtb3RvcnNwb3J0fGVufDF8fHx8MTc2NDc1NDExOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Racing car"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-neutral-950/80 via-neutral-950/70 to-neutral-950"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-6 text-center">
        <div className="max-w-4xl mx-auto">
          <p className="text-red-500 mb-4 tracking-wider text-sm sm:text-base">CORENTIN BLONDIAUX</p>
          <h1 className="text-white mb-6">
            Étudiant en Communication Automobile & Sport Automobile
          </h1>
          <p className="text-neutral-300 max-w-2xl mx-auto mb-8 text-sm sm:text-base">
            Passionné par l'univers automobile et le sport automobile, je crée des contenus visuels
            qui capturent l'essence de la vitesse, de la performance et de l'innovation.
          </p>
          <button
            onClick={scrollToProjects}
            className="bg-red-500 hover:bg-red-600 text-white px-6 sm:px-8 py-2 sm:py-3 rounded-full transition-colors inline-flex items-center gap-2 text-sm sm:text-base"
          >
            Découvrir mes projets
            <ChevronDown size={20} />
          </button>
        </div>
      </div>

      {/* Scroll Indicator */}
      <button
        onClick={scrollToProjects}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white animate-bounce"
      >
        <ChevronDown size={32} />
      </button>
    </section>
  );
}