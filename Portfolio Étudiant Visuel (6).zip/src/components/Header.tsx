import { Menu, X } from "lucide-react";
import { useState } from "react";

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setIsMenuOpen(false);
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-neutral-950/80 backdrop-blur-lg border-b border-neutral-800">
      <nav className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="text-white">
            <span className="text-red-500">PORTFOLIO</span>
          </div>

          {/* Desktop Navigation */}
          <ul className="hidden md:flex items-center gap-8">
            <li>
              <button
                onClick={() => scrollToSection("accueil")}
                className="text-neutral-300 hover:text-white transition-colors"
              >
                Accueil
              </button>
            </li>
            <li>
              <button
                onClick={() => scrollToSection("projets")}
                className="text-neutral-300 hover:text-white transition-colors"
              >
                Projets
              </button>
            </li>
            <li>
              <button
                onClick={() => scrollToSection("a-propos")}
                className="text-neutral-300 hover:text-white transition-colors"
              >
                À propos
              </button>
            </li>
            <li>
              <button
                onClick={() => scrollToSection("contact")}
                className="bg-red-500 hover:bg-red-600 text-white px-6 py-2 rounded-full transition-colors"
              >
                Contact
              </button>
            </li>
          </ul>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-white"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <ul className="md:hidden flex flex-col gap-4 mt-4 pb-4">
            <li>
              <button
                onClick={() => scrollToSection("accueil")}
                className="text-neutral-300 hover:text-white transition-colors w-full text-left"
              >
                Accueil
              </button>
            </li>
            <li>
              <button
                onClick={() => scrollToSection("projets")}
                className="text-neutral-300 hover:text-white transition-colors w-full text-left"
              >
                Projets
              </button>
            </li>
            <li>
              <button
                onClick={() => scrollToSection("a-propos")}
                className="text-neutral-300 hover:text-white transition-colors w-full text-left"
              >
                À propos
              </button>
            </li>
            <li>
              <button
                onClick={() => scrollToSection("contact")}
                className="bg-red-500 hover:bg-red-600 text-white px-6 py-2 rounded-full transition-colors w-full"
              >
                Contact
              </button>
            </li>
          </ul>
        )}
      </nav>
    </header>
  );
}
