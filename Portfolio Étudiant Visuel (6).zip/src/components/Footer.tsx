export function Footer() {
  return (
    <footer className="bg-neutral-950 border-t border-neutral-800 py-8">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-neutral-400">
            © {new Date().getFullYear()} Portfolio. Tous droits réservés.
          </div>
          <div className="text-neutral-400">
            Étudiant en Communication Automobile & Sport Automobile
          </div>
        </div>
      </div>
    </footer>
  );
}
