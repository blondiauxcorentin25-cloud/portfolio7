import { ProjectCard } from "./ProjectCard";
import audiQ8Image from "figma:asset/3215edb71b5b38ccf42d6eaf5c885e8b1cfb88fb.png";
import videoProductionImage from "figma:asset/32c8c2e04ead32bfd83fdceccfc1edb357e5038a.png";

const projects = [
  {
    id: 1,
    title: "Création de Visuels Événementiels",
    category: "Événementiel • Photo • Vidéo",
    image: audiQ8Image,
    description: "Conception de visuels photo et montage vidéo pour des événements automobiles et présentations de nouveaux modèles.",
    tags: ["Photo", "Montage Vidéo", "Événementiel"],
    type: "photo",
  },
  {
    id: 2,
    title: "Vidéos de Présentation Automobile",
    category: "Vidéo • Réseaux Sociaux",
    image: videoProductionImage,
    description: "Réalisation de vidéos de présentation de véhicules pour clients professionnels et réseaux sociaux.",
    tags: ["Montage", "Motion Design", "Social Media"],
    type: "video",
  },
  {
    id: 3,
    title: "Mondial de l'Auto 2026 - Porsche",
    category: "Projet Salon Automobile",
    image: "https://images.unsplash.com/photo-1719952475038-488da06ee3b4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3JzY2hlJTIwOTExJTIwY2FyJTIwc2hvd3xlbnwxfHx8fDE3NjQ4MzA4OTB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    description: "Organisation du stand Porsche au Mondial de l'Auto 2026 avec mise en valeur des Porsche 911 et 356.",
    tags: ["Organisation", "Porsche", "Mondial Auto 2026"],
    type: "photo",
  },
];

export function Projects() {
  return (
    <section id="projets" className="py-24 bg-neutral-900">
      <div className="container mx-auto px-4 sm:px-6">
        <div className="text-center mb-16">
          <p className="text-red-500 mb-4 tracking-wider text-sm sm:text-base">MES RÉALISATIONS</p>
          <h2 className="text-white mb-4">Projets</h2>
          <p className="text-neutral-400 max-w-2xl mx-auto text-sm sm:text-base">
            Découvrez une sélection de mes projets réalisés dans le cadre de ma formation
            en communication automobile et sport automobile.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {projects.map((project) => (
            <ProjectCard key={project.id} project={project} />
          ))}
        </div>
      </div>
    </section>
  );
}