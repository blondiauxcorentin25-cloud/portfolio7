import { Mail, Linkedin, Instagram, Phone } from "lucide-react";

export function Contact() {
  return (
    <section id="contact" className="py-24 bg-neutral-900">
      <div className="container mx-auto px-4 sm:px-6">
        <div className="text-center mb-16">
          <p className="text-red-500 mb-4 tracking-wider text-sm sm:text-base">RESTONS EN CONTACT</p>
          <h2 className="text-white mb-4">Contact</h2>
          <p className="text-neutral-400 max-w-2xl mx-auto text-sm sm:text-base">
            Un projet en tête ? Une collaboration à envisager ? N'hésitez pas à me contacter !
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8 mb-12">
            <a
              href="mailto:blondiauxcorentin@yahoo.com"
              className="bg-neutral-800 hover:bg-neutral-750 border border-neutral-700 p-6 sm:p-8 rounded-xl transition-all hover:border-red-500 group"
            >
              <div className="flex items-start gap-4">
                <div className="bg-neutral-900 p-3 sm:p-4 rounded-lg group-hover:bg-red-500 transition-colors flex-shrink-0">
                  <Mail className="text-red-500 group-hover:text-white transition-colors" size={24} />
                </div>
                <div className="min-w-0">
                  <p className="text-neutral-400 mb-2 text-sm sm:text-base">Email</p>
                  <p className="text-white text-sm sm:text-base break-words">blondiauxcorentin@yahoo.com</p>
                </div>
              </div>
            </a>

            <a
              href="tel:+33624757071"
              className="bg-neutral-800 hover:bg-neutral-750 border border-neutral-700 p-6 sm:p-8 rounded-xl transition-all hover:border-red-500 group"
            >
              <div className="flex items-start gap-4">
                <div className="bg-neutral-900 p-3 sm:p-4 rounded-lg group-hover:bg-red-500 transition-colors flex-shrink-0">
                  <Phone className="text-red-500 group-hover:text-white transition-colors" size={24} />
                </div>
                <div>
                  <p className="text-neutral-400 mb-2 text-sm sm:text-base">Téléphone</p>
                  <p className="text-white text-sm sm:text-base">06.24.75.70.71</p>
                </div>
              </div>
            </a>
          </div>

          <div className="text-center mb-8">
            <h3 className="text-white mb-6">Réseaux sociaux</h3>
            <div className="flex justify-center gap-4 sm:gap-6">
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-neutral-800 hover:bg-red-500 p-6 rounded-xl transition-all transform hover:scale-110 group"
              >
                <Linkedin className="text-white" size={32} />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-neutral-800 hover:bg-red-500 p-6 rounded-xl transition-all transform hover:scale-110 group"
              >
                <Instagram className="text-white" size={32} />
              </a>
            </div>
          </div>

          <div className="bg-neutral-800 border border-neutral-700 p-6 sm:p-8 rounded-xl text-center">
            <h4 className="text-white mb-4">Disponibilité</h4>
            <p className="text-neutral-300 mb-4 text-sm sm:text-base">
              Actuellement étudiant en 3ᵉ année de Bachelor Marketing, Publicité et Communication à ITM Graduate School – Le Mans, je suis à la recherche d'un stage pour valider mon année. Selon les exigences de ma formation, je peux effectuer soit un stage initial de deux à six mois à partir de juin, soit un stage alterné pouvant aller jusqu'à 132 jours par année scolaire (ou 924 heures).
            </p>
            <div className="flex items-center justify-center gap-2">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-green-500 text-sm sm:text-base">Disponible</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}