import { Briefcase, GraduationCap, Award, Zap } from "lucide-react";

export function About() {
  const skills = [
    { name: "Photographie & Retouche", level: 90 },
    { name: "Design Graphique", level: 85 },
    { name: "Montage Vidéo", level: 80 },
    { name: "Réseaux Sociaux", level: 95 },
    { name: "Rédaction", level: 75 },
    { name: "Motion Design", level: 70 },
  ];

  return (
    <section id="a-propos" className="py-24 bg-neutral-950">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <p className="text-red-500 mb-4 tracking-wider">QUI SUIS-JE ?</p>
          <h2 className="text-white mb-4">À propos</h2>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <p className="text-neutral-300 mb-6">
              Je m'appelle Corentin Blondiaux, j'ai 22 ans et je suis étudiant passionné en communication automobile 
              et sport automobile. Je combine ma passion pour l'univers de la course et mes compétences créatives 
              pour créer des contenus impactants et authentiques.
            </p>
            <p className="text-neutral-300 mb-6">
              Mon objectif est de capturer l'émotion, la vitesse et la performance à travers différents
              médias : photographie, vidéo, design graphique et stratégies de communication digitale.
            </p>
            <p className="text-neutral-300">
              Toujours à l'affût des dernières tendances et innovations dans le domaine automobile,
              je développe continuellement mes compétences pour offrir des créations de qualité
              professionnelle.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
            <div className="bg-neutral-900 p-4 sm:p-6 rounded-lg border border-neutral-800">
              <GraduationCap className="text-red-500 mb-4" size={32} />
              <h3 className="text-white mb-2">Formation</h3>
              <p className="text-neutral-400 text-sm sm:text-base">ITM Graduate School Le Mans</p>
            </div>
            <div className="bg-neutral-900 p-4 sm:p-6 rounded-lg border border-neutral-800">
              <Briefcase className="text-red-500 mb-4" size={32} />
              <h3 className="text-white mb-2">Disponibilité</h3>
              <p className="text-neutral-400 text-sm sm:text-base">Recherche de stage 2-6 mois dès juin ou stage alterné</p>
            </div>
            <div className="bg-neutral-900 p-4 sm:p-6 rounded-lg border border-neutral-800">
              <Award className="text-red-500 mb-4" size={32} />
              <h3 className="text-white mb-2">Expertise</h3>
              <p className="text-neutral-400 text-sm sm:text-base">Communication visuelle & digitale</p>
            </div>
            <div className="bg-neutral-900 p-4 sm:p-6 rounded-lg border border-neutral-800">
              <Zap className="text-red-500 mb-4" size={32} />
              <h3 className="text-white mb-2">Passion</h3>
              <p className="text-neutral-400 text-sm sm:text-base">Sport automobile & performance</p>
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-white mb-8 text-center">Compétences</h3>
          <div className="max-w-3xl mx-auto grid md:grid-cols-2 gap-6">
            {skills.map((skill, index) => (
              <div key={index}>
                <div className="flex justify-between mb-2">
                  <span className="text-neutral-300">{skill.name}</span>
                  <span className="text-red-500">{skill.level}%</span>
                </div>
                <div className="h-2 bg-neutral-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-red-500 to-red-600 rounded-full transition-all duration-1000"
                    style={{ width: `${skill.level}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}