import { Play, Lightbulb } from "lucide-react";
import { useState } from "react";

export function SkillsVideo() {
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <section className="py-16 bg-neutral-900">
      <div className="container mx-auto px-4 sm:px-6">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 mb-4">
            <Lightbulb className="text-red-500" size={24} />
            <p className="text-red-500 tracking-wider text-sm sm:text-base">MES COMPÉTENCES EN ACTION</p>
          </div>
          <h2 className="text-white mb-4">Pourquoi mes compétences pour votre entreprise ?</h2>
          <p className="text-neutral-400 max-w-2xl mx-auto text-sm sm:text-base">
            Une vidéo humoristique pour découvrir comment mes compétences peuvent servir votre projet
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="relative aspect-video bg-neutral-800 rounded-xl overflow-hidden border-2 border-red-500/20 shadow-xl">
            {!isPlaying ? (
              <div 
                className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-neutral-800 to-neutral-900 cursor-pointer"
                style={{
                  backgroundImage: 'url(https://img.youtube.com/vi/AfM5EHZtI5k/maxresdefault.jpg)',
                  backgroundSize: 'cover',
                  backgroundPosition: 'center'
                }}
                onClick={() => setIsPlaying(true)}
              >
                <div className="absolute inset-0 bg-black/40"></div>
                <div className="text-center relative z-10">
                  <button className="group mb-4">
                    <div className="w-20 h-20 bg-red-500 hover:bg-red-600 rounded-full flex items-center justify-center transition-all transform group-hover:scale-110 shadow-lg shadow-red-500/50">
                      <Play className="text-white ml-1" size={32} fill="white" />
                    </div>
                  </button>
                  <p className="text-white mb-2">Cliquez pour voir la vidéo</p>
                  <p className="text-neutral-400 text-sm">Ton humoristique • Démonstration de compétences</p>
                </div>
              </div>
            ) : (
              <iframe
                className="w-full h-full"
                src="https://www.youtube.com/embed/AfM5EHZtI5k?autoplay=1"
                title="Mes compétences en action"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}