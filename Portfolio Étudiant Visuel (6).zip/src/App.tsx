import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { SkillsVideo } from "./components/SkillsVideo";
import { VideoShowcase } from "./components/VideoShowcase";
import { Projects } from "./components/Projects";
import { About } from "./components/About";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-neutral-950">
      <Header />
      <main>
        <Hero />
        <SkillsVideo />
        <VideoShowcase />
        <Projects />
        <About />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}