
  # Portfolio Étudiant Visuel

  This is a code bundle for Portfolio Étudiant Visuel. The original project is available at https://www.figma.com/design/o5208nwApVwESQADpF0otP/Portfolio-%C3%89tudiant-Visuel.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  